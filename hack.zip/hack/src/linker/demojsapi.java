package linker;
import javax.speech.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.*;
import javax.speech.synthesis.*;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class demojsapi
{
String speaktext;
public void dospeak(String speak,String 
voicename)
{
speaktext=speak;
String voiceName =voicename;
try
{
SynthesizerModeDesc desc = new
SynthesizerModeDesc(null,"general", 
Locale.US,null,null);
Synthesizer synthesizer = 
Central.createSynthesizer(desc);
synthesizer.allocate();
synthesizer.resume();
desc = (SynthesizerModeDesc) 
synthesizer.getEngineModeDesc();
Voice[] voices = desc.getVoices();
Voice voice = null;
for (int i = 0; i < voices.length; i++)
{
if (voices[i].getName().equals(voiceName))
{
voice = voices[i];
break;
}
} synthesizer.getSynthesizerProperties().setVoice(voice);
synthesizer.speakPlainText(speaktext, null); synthesizer.waitEngineState(Synthesizer.QUEUE_EMPTY);
synthesizer.deallocate();
}catch (Exception e)
{ String message = " missing speech.properties in " + System.getProperty("user.home") + "\n"; 
System.out.println(""+e);
System.out.println(message);}
}
public static void main (String[] args)
{pqr();}
public static void pqr(){
	String str="hi,";
	String pageContent=str;
	
	WebClient webClient = new WebClient(BrowserVersion.CHROME);
	webClient.getOptions().setJavaScriptEnabled(true);
	HtmlPage page;
	try {
		//page = webClient.getPage("https://www.textise.net/showText.aspx?strURL=http%253A//www.google.com/search%253Fq%253Dbooks#search");
		page = webClient.getPage("https://text.npr.org/");
		pageContent=page.asText();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	//String pageContent=page.asText();
	
	
	
	
demojsapi obj=new demojsapi();
obj.dospeak(pageContent,"kevin16");
}

}