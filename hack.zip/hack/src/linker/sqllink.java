package linker;



import java.sql.DriverManager;

import com.mysql.jdbc.Connection;


public class sqllink {


		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://localhost/hack";
		static Connection conn;
		static String USER="root";
		static String PASS="0000";


	public static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connecting to database...");
			conn=(Connection) DriverManager.getConnection(DB_URL,USER,PASS);
			return conn;
		} catch (Exception e){
								e.printStackTrace();
							  }
		return null;

	}
	void closeConnection()
	{
		try {
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	}
	
