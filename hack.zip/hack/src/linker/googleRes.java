package linker;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class googleRes {
	public static void abc() throws Exception {
	//@SuppressWarnings("resource")
	WebClient webClient = new WebClient(BrowserVersion.CHROME);
	webClient.getOptions().setJavaScriptEnabled(true);
	HtmlPage page = webClient.getPage("https://text.npr.org/");
	String pageContent=page.asText();
	System.out.println(pageContent);
}	
}